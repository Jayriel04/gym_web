<?php
session_start();
include 'connect-DB.php';

if (isset($_POST['register_user'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phoneNumber = $_POST['phoneNumber'];
    $address = $_POST['address'];

    $sql = "INSERT INTO users (first_name, last_name, email, phone_number, address) 
            VALUES ('$firstName', '$lastName', '$email', '$phoneNumber', '$address')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the membership page
        header('location: ../../front-end/membership.html');
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

if (isset($_POST['update_member'])) {
    $membershipPrice = $_POST['membershipPrice'];
    $membershipType = $_POST['membershipType'];

    $_SESSION['membershipType'] = $membershipType;
    $_SESSION['membershipPrice'] = $membershipPrice;

    header('Location: ../../front-end/transaction.php');
    exit;
}

if (isset($_POST['confirm'])) {
    $paymentMethod = $_POST['paymentMethod'];

    $_SESSION['paymentMethod'] = $paymentMethod;

    $cardNumber = $_POST['cardNumber'];
    $cardDate = $_POST['cardDate'];
    $cardCode = $_POST['cardCode'];
    $cardAddress = $_POST['cardAddress'];
    $cardName = $_POST['cardName'];

    $sql = "INSERT INTO payment (card_number, card_date, card_code, card_address, card_name) 
            VALUES ('$cardNumber', '$cardDate', '$cardCode', '$cardAddress', '$cardName')";

    if ($conn->query($sql) === TRUE) {
        // echo "saging";
        // Redirect to the membership page
        header('Location: ../../front-end/reciept.php');
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // header('Location: ../../front-end/reciept.php');
    // exit;
}

$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $firstName = $row['first_name'];
        $lastName = $row['last_name'];
        $email = $row['email'];
        $phonenumber = $row['phone_number'];
        $address = $row['address'];

        // echo "First Name: " . $firstName . "<br>";
        // echo "Last Name: " . $lastName . "<br>";
    }
} else {
    echo "No data found.";
}

// if (isset($_POST['confirm'])) {
//     $cardNumber = $_POST['cardNumber'];
//     $cardDate = $_POST['cardDate'];
//     $cardCode = $_POST['cardCode'];
//     $cardAddress = $_POST['cardAddress'];
//     $cardName = $_POST['cardName'];

//     $sql = "INSERT INTO payments (card_number, card_date, card_code, card_address, card_name) 
//             VALUES ('$cardNumber', '$cardDate', '$cardCode', '$cardAddress', '$cardName')";

//     if ($conn->query($sql) === TRUE) {
//         echo "saging";
//         // Redirect to the membership page
//         // header('Location: ../../front-end/reciept.php');
//         exit;
//     } else {
//         echo "Error: " . $sql . "<br>" . $conn->error;
//     }
// }



$conn->close();
?>