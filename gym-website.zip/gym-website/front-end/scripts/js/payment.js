(document).ready(function() {
    // Load Personal Information form
    $('#personalInfoForm').load('personalInfo.html');
  
    // Handle Personal Information form submission
    $('#personalInfoForm').on('submit', function(e) {
      e.preventDefault();
      $('#paymentTypeForm').load('paymentType.html');
      $('.nav-tabs a[href="#paymentType"]').tab('show');
    });
  
    // Handle Payment Type form submission
    $('#paymentTypeForm').on('submit', function(e) {
      e.preventDefault();
      $('#receiptForm').load('receipt.html', function() {
        var firstName = $('#firstName').val();
        var lastName = $('#lastName').val();
        var email = $('#email').val();
        var phoneNumber = $('#phoneNumber').val();
        var address = $('#address').val();
        var membershipType = $('#membershipType').val();
  
        $('#receiptName').text(firstName + ' ' + lastName);
        $('#receiptEmail').text(email);
        $('#receiptPhoneNumber').text(phoneNumber);
        $('#receiptAddress').text(address);
        $('#receiptMembershipType').text(membershipType);
  
        $('.nav-tabs a[href="#receipt"]').tab('show');
      });
    });

    // Update navigation header
    function updateNavHeader(tabId) {
      const navLinks = document.querySelectorAll('.nav-link');

      for (let i = 0; i < navLinks.length; i++) {
          if (navLinks[i].getAttribute('href') === `#${tabId}`) {
              navLinks[i].classList.add('active');
          } else {
              navLinks[i].classList.remove('active');
          }
      }
  }

  // Call updateNavHeader when "Next" button is clicked
  $('.btn-primary').click(function (event) {
      event.preventDefault();
      const targetTab = $(this).attr('data-target');
      updateNavHeader(targetTab);
      $(`a[href="${targetTab}"]`).tab('show');

      // Get user input data from input tab
      if (targetTab === '#payment') {
          const name = $('#name').val();
          const email = $('#email').val();
          const selectedOffer = $('#selected-offer').val();

          // Set user input data in payment tab
          $('#payment-name').text(name);
          $('#payment-email').text(email);
          $('#payment-offer').text(selectedOffer);
      }
  });

  // Call updateNavHeader when "Next" button is clicked
  $('.btn-primary').click(function (event) {
      event.preventDefault();
      const targetTab = $(this).attr('data-target');
      updateNavHeader(targetTab);
      $(`a[href="${targetTab}"]`).tab('show');
  });
  
  // Display receipt information
  if (tabId === 'receipt') {
      const infoData = document.getElementById('info-data').innerHTML;
      const offerData = document.getElementById('offer-data').innerHTML;
      const paymentData = document.getElementById('payment-data').innerHTML;

      document.getElementById('receipt-info').innerHTML = `<h4>Information:</h4>${infoData}`;
      document.getElementById('receipt-offer').innerHTML = `<h4>Offer:</h4>${offerData}`;
      document.getElementById('receipt-payment').innerHTML = `<h4>Payment:</h4>${paymentData}`;
  }
  
  });